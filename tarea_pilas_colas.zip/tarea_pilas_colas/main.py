from pasajero import Pasajero
from mi_pila import MiPila
from mi_cola import MiCola

pila = MiPila(10)
cola = MiCola(10)


def leer_entero(mensaje):
    while True:
        try:
            return int(input(mensaje))
        except ValueError:
            print("  Debe ingresar un número entero.")


def leer_pasajero():
    print("\nDatos del pasajero")
    numero = leer_entero("  Número: ")
    nombre = input("  Nombre: ").strip()
    cedula = input("  Cédula: ").strip()
    edad = leer_entero("  Edad: ")
    fecha = input("  Fecha de vuelo (AAAA-MM-DD): ").strip()
    destino = input("  Destino: ").strip()
    asiento = input("  Asiento: ").strip().upper()

    if nombre == "" or cedula == "" or fecha == "" or destino == "" or asiento == "":
        print("  Todos los campos de texto son obligatorios.")
        return None
    if edad < 0:
        print("  La edad no puede ser negativa.")
        return None

    return Pasajero(numero, nombre, cedula, edad, fecha, destino, asiento)


def datos_prueba():
    return [
        Pasajero(1005, "Diana", "0923456789", 22, "2026-11-15", "Quito", "12A"),
        Pasajero(1002, "Ana", "0912345678", 28, "2026-11-15", "Lima", "03C"),
        Pasajero(1009, "Luis", "0987654321", 35, "2026-11-20", "Bogotá", "18F"),
        Pasajero(1004, "Beto", "0934567890", 16, "2026-11-20", "Quito", "07B"),
        Pasajero(1001, "Elena", "0901234567", 41, "2026-11-22", "Lima", "01A")
    ]


def mostrar_opciones(titulo, entrar, salir, ver):
    print(f"\n========== {titulo} ==========")
    print(f" 1. {entrar:<12}  2. Listar          3. {salir}")
    print(f" 4. {ver:<12}  5. Buscar          6. Modificar")
    print(" 7. Eliminar por número         8. Copiar")
    print(" 9. Longitud / ¿vacía?")
    print(" C. Cargar datos de prueba      0. Volver")


def menu_pila():
    while True:
        mostrar_opciones("MENÚ 1 - PILA (LIFO)", "Apilar", "Desapilar", "Ver tope")
        op = input("Opción: ").strip().upper()

        if op == "1":
            pasajero = leer_pasajero()
            if pasajero is not None and pila.apilar(pasajero):
                print("  Pasajero agregado. Ahora está en el tope.")
        elif op == "2":
            pila.listar()
        elif op == "3":
            pasajero = pila.desapilar()
            if pasajero is None:
                print("  No se puede desapilar: la pila está vacía.")
            else:
                print("  Pasajero desapilado:", pasajero)
        elif op == "4":
            pasajero = pila.ver_tope()
            if pasajero is None:
                print("  La pila está vacía.")
            else:
                print("  Pasajero en el tope:", pasajero)
        elif op == "5":
            numero = leer_entero("  Número de pasajero a buscar: ")
            posicion = pila.buscar(numero)
            if posicion == -1:
                print("  El pasajero no existe.")
            else:
                print(f"  Encontrado en la posición [{posicion}]: {pila.datos[posicion]}")
        elif op == "6":
            numero = leer_entero("  Número de pasajero a modificar: ")
            destino = input("  Nuevo destino: ").strip()
            asiento = input("  Nuevo asiento: ").strip().upper()
            if destino == "" or asiento == "":
                print("  El destino y el asiento son obligatorios.")
            elif pila.modificar(numero, destino, asiento):
                print("  Datos actualizados correctamente.")
            else:
                print("  No se encontró el pasajero.")
        elif op == "7":
            numero = leer_entero("  Número de pasajero a eliminar: ")
            if pila.eliminar_por_numero(numero):
                print("  Pasajero eliminado. El orden de la pila se mantiene.")
            else:
                print("  No se encontró el pasajero.")
        elif op == "8":
            copia = pila.copiar()
            print("  Copia de la pila:")
            copia.listar()
        elif op == "9":
            print("  Longitud:", pila.longitud())
            if pila.esta_vacia():
                print("  La pila está vacía.")
            else:
                print("  La pila contiene pasajeros.")
        elif op == "C":
            cargados = 0
            for pasajero in datos_prueba():
                if pila.apilar(pasajero):
                    cargados = cargados + 1
            print(f"  Datos de prueba agregados: {cargados}. Los números repetidos no se duplican.")
        elif op == "0":
            break
        else:
            print("  Opción no válida.")


def menu_cola():
    while True:
        mostrar_opciones("MENÚ 2 - COLA (FIFO)", "Encolar", "Desencolar", "Ver frente")
        op = input("Opción: ").strip().upper()

        if op == "1":
            pasajero = leer_pasajero()
            if pasajero is not None and cola.encolar(pasajero):
                print("  Pasajero agregado al final de la cola.")
        elif op == "2":
            cola.listar()
        elif op == "3":
            pasajero = cola.desencolar()
            if pasajero is None:
                print("  No se puede desencolar: la cola está vacía.")
            else:
                print("  Pasajero desencolado:", pasajero)
        elif op == "4":
            pasajero = cola.ver_frente()
            if pasajero is None:
                print("  La cola está vacía.")
            else:
                print("  Pasajero al frente:", pasajero)
        elif op == "5":
            numero = leer_entero("  Número de pasajero a buscar: ")
            posicion = cola.buscar(numero)
            if posicion == -1:
                print("  El pasajero no existe.")
            else:
                print(f"  Encontrado en la posición [{posicion}]: {cola.datos[posicion]}")
        elif op == "6":
            numero = leer_entero("  Número de pasajero a modificar: ")
            destino = input("  Nuevo destino: ").strip()
            asiento = input("  Nuevo asiento: ").strip().upper()
            if destino == "" or asiento == "":
                print("  El destino y el asiento son obligatorios.")
            elif cola.modificar(numero, destino, asiento):
                print("  Datos actualizados correctamente.")
            else:
                print("  No se encontró el pasajero.")
        elif op == "7":
            numero = leer_entero("  Número de pasajero a eliminar: ")
            if cola.eliminar_por_numero(numero):
                print("  Pasajero eliminado. Los demás conservan su orden.")
            else:
                print("  No se encontró el pasajero.")
        elif op == "8":
            copia = cola.copiar()
            print("  Copia de la cola:")
            copia.listar()
        elif op == "9":
            print("  Longitud:", cola.longitud())
            if cola.esta_vacia():
                print("  La cola está vacía.")
            else:
                print("  La cola contiene pasajeros.")
        elif op == "C":
            cargados = 0
            for pasajero in datos_prueba():
                if cola.encolar(pasajero):
                    cargados = cargados + 1
            print(f"  Datos de prueba agregados: {cargados}. Los números repetidos no se duplican.")
        elif op == "0":
            break
        else:
            print("  Opción no válida.")


def main():
    while True:
        print("\n===== TAREA PILAS Y COLAS - PASAJEROS =====")
        print("1. Menú 1 - Pila")
        print("2. Menú 2 - Cola")
        print("3. Salir")
        op = input("Opción: ").strip()

        if op == "1":
            menu_pila()
        elif op == "2":
            menu_cola()
        elif op == "3":
            print("¡Hasta pronto!")
            break
        else:
            print("Opción no válida.")


if __name__ == "__main__":
    main()
